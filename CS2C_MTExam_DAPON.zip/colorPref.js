let colors = [];

for (let i = 0; i < 3; i++) {
let color = prompt("Enter a color:");
colors.push(color);
console.log("Favorite colors:", colors);
}