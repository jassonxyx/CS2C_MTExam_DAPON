//ask the user's age
let yearAge = parseInt(prompt("Enter you age:"));

//use if-else statement to categorize
let category = "";
if (yearAge < 5) {
  category = "Toddler";
} else if (yearAge <= 12) {
  category = "Child";
} else if (yearAge <= 19) {
  category = "Teenager";
} else if (yearAge <= 35) {
  category = "Young Adult";
} else if (yearAge <= 60) {
  category = "Middle Age";
} else {
  category = "Senior";
}
console.log("Age: "+ yearAge);
console.log("Group: "+ category);