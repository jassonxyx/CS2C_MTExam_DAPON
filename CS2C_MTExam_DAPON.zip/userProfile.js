let yourName = prompt("What is your fullName: ");
let age = parseInt(prompt("What is your age:"));
let favNumber = parseInt(prompt("What is your favorite number:"));
let favColor = prompt("What is your favorite color:");

console.log('Full Name: '+yourName);
console.log('Age: '+age);
console.log('Favorite Number: '+favNumber );
console.log('Favorite Color: '+favColor );