let userProfile = {
  fullName: "Mark Jasson Dapon",
  age: 19,
  favoriteNumber: 11,
  favoriteColors: ["Red", "Blue", "Gray"]
};

console.log(userProfile);