let subTitle = prompt("Enter subject title:");
let classSched = prompt("Enter class schedule (Time, Days):");
let room = prompt("Enter classroom:");
let classInst = prompt("Enter class instructor:");
let student = prompt("Enter student name:");

console.log(student + " is currently enrolled in " + subTitle + " with a class schedule of " + classSched + " at room " + room + ". The instructor for the subject is " + classInst + ".");