let DSA = [];
let PL = [];
let Networks = [];

let currentSub = null;

while (true) {
  if (!currentSub) {
    console.log("Select a subject:\n(A) DSA\n(B) PL\n(C) Networks");
    let choice = prompt("Enter your choice:(A)DSA,(B)PL,(C)Networks");
    switch (choice.toUpperCase()) {
      case "A":
        currentSub = DSA;
        break;
      case "B":
        currentSub = PL;
        break;
      case "C":
        currentSub = Networks;
        break;
    }
  }

  if (currentSub) {
    console.log("Select an operation:\n(A) Enroll\n(B) Unenroll\n(C) Select Another Subject\n(D) Exit");
    let operation = prompt("Enter your choice:(A)Enroll,(B)Unenroll,(C)Select Another Subject,(D)Exit");
    switch (operation.toUpperCase()) {
      case "A":
        let name = prompt("Enter student name:");
        currentSub.push(name);
        console.log("Enrolled: " + currentSub.join(", "));
        break;
      case "B":
        if (currentSub.length == 0) {
          console.log("No students enrolled.");
        } else {
          console.log("Enrolled students: " + currentSub.join(", "));
          let index = parseInt(prompt("Enter student number to unenroll:")) - 1;
          if (index >= 0 && index < currentSub.length) {
            currentSub.splice(index, 1);
            console.log("Unenrolled: " + currentSub.join(", "));
          }
        }
        break;
      case "C":
        currentSub = null;
        break;
      case "D":
        console.log("DSA: " + DSA.join(", ") + "\nPL: " + PL.join(", ") + "\nNetworks: " + Networks.join(", "));
        process.exit();
    }
 }
}