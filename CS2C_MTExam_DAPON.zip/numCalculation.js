let favNumber = 11;
let guess;

while (true)
{
  guess = parseInt(prompt("Guess my favorite number:"));

  if (guess < favNumber) {
    console.log("Too low");
  } else if (guess > favNumber) {
    console.log("Too high");
  } else {
    console.log("Correct!");
    break;
  }
}